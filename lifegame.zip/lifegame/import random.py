# generate_etat_initial_planeur.py

def generate_etat_initial_planeur(width, height, filename):
    with open(filename, 'w') as file:
        # Écrire la taille de la grille
        file.write(f"{width} {height}\n")
        
        # Créer une grille vide (toutes les cellules sont mortes)
        grid = [['0' for _ in range(width)] for _ in range(height)]
        
        # Coordonnées de départ pour le planeur (au centre de la grille)
        x = width // 2
        y = height // 2
        
        # Configuration du planeur
        planeur_coords = [
            (x, y),
            (x + 1, y),
            (x + 2, y),
            (x + 2, y - 1),
            (x + 1, y - 2)
        ]
        
        # Placer le planeur dans la grille
        for cx, cy in planeur_coords:
            if 0 <= cx < width and 0 <= cy < height:
                grid[cy][cx] = '1'
        
        # Écrire la grille dans le fichier
        for row in grid:
            file.write(' '.join(row) + '\n')

if __name__ == "__main__":
    # Spécifiez la largeur et la hauteur de la grille
    width = 80
    height = 80
    filename = "etat_initial.txt"
    generate_etat_initial_planeur(width, height, filename)
    print(f"Le fichier '{filename}' a été généré avec un planeur au centre d'une grille de {width}x{height}.")
